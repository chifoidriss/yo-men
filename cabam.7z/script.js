/*jshint esversion: 6 */

const root = document.body;
var cache = root.innerHTML;
const nodes = [];
const z = root.getElementsByTagName("*");
const prefix = '#';
const dRepeat = prefix + 'repeat';
const dIf = prefix + 'if';
const dClass = prefix + 'class';
const dIfR = prefix + '*if';
const dClassR = prefix + '*class';
const dModel = prefix + 'model';
const dClick = prefix + 'click';
const dDblclick = prefix + 'dblclick';
const dInclude = prefix + 'include';
const dRouting = prefix + 'link';
const dTabRouting = prefix + 'tab';
const outletName = '_outlet';
const DOpenDrawer = prefix + 'openDrawer';
const DCloseDrawer = prefix + 'closeDrawer';
const DOpenModal = prefix + 'openModal';
const DCloseModal = prefix + 'closeModal';

const extensionFile = '.html';
const viewsFolder = './';

const ROUTES = [];


function hIfRepeat(elementRef) {
    var elements = elementRef.getElementsByTagName("*");
    for (var i = 0; i < elements.length; i++) {
        const element = elements[i];
        if (element.hasAttribute(dIfR)) {
            const attribute = element.getAttribute(dIfR);
            const varName = attribute.split('.').shift();
            var properties = attribute.split('.');
            properties.shift();
            properties = properties.join('.');

            const output = eval('try{JSON.parse('+varName+').'+properties+'}catch(e){'+varName+'.'+properties+'}');
            if (!output)
                element.remove();
            else
                element.removeAttribute(dIfR);
        }
    }
}

function hClassRepeat(elementRef) {
    var elements = elementRef.getElementsByTagName("*");

    for (var i = 0; i < elements.length; i++) {
        const element = elements[i];
        console.log(element);

        if (element.hasAttribute(dClassR)) {
            const attribute = element.getAttribute(dClassR);

            // const output = eval('' + attribute);
            // window['classes'] = attribute;
            // console.log(window['classes']);
            console.log(attribute);
        }
    }
}

function interpolationRepeat(elementRef) {
    const element = elementRef;
    const regex = /\[\[[ ]*\$+([a-zA-Z_]+[\w$\.'"()]*)[ ]*\]\]/mg;

    element.innerHTML = element.innerHTML.replace(regex, function (match, $1) {
        return eval($1);
    });
}


function superLoader(elementRef) {
    const htmlElement = elementRef || root;
    const htmlElements = htmlElement.getElementsByTagName('*');

    // Remove comments elements
    htmlElement.innerHTML = htmlElement.innerHTML.replace(/<!--(.*)-->/mg, function (match) {
        return '';
    });

    // Interpolation variables
    const regex = /\[\[[ ]*([a-zA-Z_]+[\w$\.'"()]*)[ ]*\]\]/mg;
    htmlElement.innerHTML = htmlElement.innerHTML.replace(regex, function (match, $1) {
        nodes.push({varName: $1, node: match});
        return '<out _state="'+$1+'">'+eval($1)+'</out>';
        // return '<out _state="'+$1.trim()+'">'+window[$1]+'</out>';
    });

    for (var i = 0; i < htmlElements.length; i++) {
        const element = htmlElements[i];

        if (element.hasAttribute(dRepeat)) {
            const parent = element.parentElement;
            const attribut = element.getAttribute(dRepeat).trim();

            const locale = attribut.split('in',2)[0].trim();
            const objet = attribut.split('in',2)[1].trim();

            const objectNode = {varName: objet, node: parent.innerHTML};
            nodes.push(objectNode);

            window[objet].forEach(elt => {
                window[locale] = elt;

                const enfant = element.cloneNode(true);
                enfant.removeAttribute(dRepeat);
                parent.insertBefore(enfant, element);
                interpolationRepeat(enfant);
                hIfRepeat(enfant);
                // hClassRepeat(enfant);
                delete window[locale];
            });
            parent.setAttribute('_state', objet);
            element.remove();
        }

        if (element.hasAttribute(dIf)) {
            const attribute = element.getAttribute(dIf).trim();
            if (!eval(attribute))
                element.remove();
            else
                element.removeAttribute(dIf);
        }

        if (element.hasAttribute(dClass)) {
            const attribute = element.getAttribute(dClass).trim();
            if (!eval(attribute))
                element.remove();
            else
                element.removeAttribute(dClass);
        }

        if (element.hasAttribute(dInclude)) {
            const file = element.getAttribute(dInclude).trim();

            const http = new XMLHttpRequest();
            http.onreadystatechange = () => {
                if (this.readyState == 4) {
                    if (this.status == 200) {
                        element.innerHTML = this.responseText;
                        return superLoader(element);
                    } else {
                        element.innerHTML = createErrorPage(this.status, this.statusText);
                    }
                    element.removeAttribute(dInclude);
                }
            }
            http.open("GET", file+extensionFile);
            http.send();
        }

        if (element.hasAttribute(dRouting)) {
            const attribute = element.getAttribute(dRouting).trim();
            const newUrl = window.location.host + '/#' + attribute;

            element.setAttribute('href', newUrl);

            element.addEventListener('click', (event) => {
                event.preventDefault();
                addPush();

                navigate(attribute, htmlElement);

                removePush();

                // element.removeAttribute(dRouting);
            });
        }

        if (element.hasAttribute(dTabRouting)) {
            const attribute = element.getAttribute(dTabRouting).trim();

            element.addEventListener('click', function (event) {
                event.preventDefault();
                if (!element.classList.contains('active')) {
                    navigate(attribute, htmlElement);
                    const elementActive = element.parentElement.querySelector('.tab-item.active');
                    elementActive.classList.remove('active');
                    element.classList.add('active');
                }
                element.removeAttribute(dTabRouting);
            });
        }

        if (element.hasAttribute(dModel)) {
            const attribute = element.getAttribute(dModel).trim();
            element.value = eval(attribute);

            if (element.nodeName == 'select') {
                element.addEventListener('change', function (event) {
                    const stringVar = attribute+'="'+this.value+'"';
                    eval(stringVar);
                    
                    const allOccurrences = htmlElement.querySelectorAll('out[_state="'+attribute+'"]');
                    allOccurrences.forEach(elt => {
                        elt.innerHTML = eval(attribute);
                    });
                    element.removeAttribute(dModel);
                });
            } else {
                element.addEventListener('keyup', function (event) {
                    const stringVar = attribute+'="'+this.value+'"';
                    eval(stringVar);
                    
                    const allOccurrences = htmlElement.querySelectorAll('out[_state="'+attribute+'"]');
                    allOccurrences.forEach(elt => {
                        elt.innerHTML = eval(attribute);
                    });
                    element.removeAttribute(dModel);
                });
            }
        }

        if (element.hasAttribute(dClick)) {
            const attribute = element.getAttribute(dClick).trim();
            element.addEventListener('click', (event) => {
                triggerEvent(event, attribute);
            });
            element.removeAttribute(dClick);
        }

        if (element.hasAttribute(dDblclick)) {
            const attribute = element.getAttribute(dDblclick).trim();
            element.addEventListener('dblclick', (event) => {
                triggerEvent(event, attribute);
            });
            element.removeAttribute(dDblclick);
        }
        
        if (element.hasAttribute(DOpenDrawer)) {
            const attribute = element.getAttribute(DOpenDrawer);
            element.addEventListener('click', (event) => {
                event.preventDefault();
                openDrawer(attribute);
            });
            element.removeAttribute(DOpenDrawer);
        }

        if (element.hasAttribute(DCloseDrawer)) {
            const attribute = element.getAttribute(DCloseDrawer);
            element.addEventListener('click', (event) => {
                event.preventDefault();
                closeDrawer(attribute);
            });
            element.removeAttribute(DCloseDrawer);
        }

        if (element.hasAttribute(DOpenModal)) {
            const attribute = element.getAttribute(DOpenModal);
            element.addEventListener('click', (event) => {
                event.preventDefault();
                openModal(attribute);
            });
            element.removeAttribute(DOpenModal);
        }

        if (element.hasAttribute(DCloseModal)) {
            const attribute = element.getAttribute(DCloseModal);
            element.addEventListener('click', (event) => {
                event.preventDefault();
                closeModal(attribute);
            });
            element.removeAttribute(DCloseModal);
        }
    }
    splashScreen();
    return htmlElement;
}

function getCache() {
    const body = document.createElement('body');
    body.innerHTML = cache;
    return body;
}
function setCache(innerHTML, name) {
    const body = document.createElement('body');
    body.innerHTML = cache;
    body.querySelector('*['+outletName+'="'+name+'"]').innerHTML = innerHTML;
    cache = body.innerHTML;
}

function createErrorPage(status, statusText) {
    const rootDiv = document.createElement('div');
    const div = document.createElement('div');
    div.style.position = 'fixed';
    div.style.top = '50%';
    div.style.right = 0;
    div.style.bottom = 0;
    div.style.left = 0;
    div.style.transform = 'translateY(-50%)';
    div.style.display = 'flex';
    div.style.flexDirection = 'column';
    div.style.alignItems = 'center';
    div.style.justifyContent = 'center';

    const h1 = document.createElement('h1');
    const h4 = document.createElement('h4');
    h1.style.marginBottom = 0;
    h4.style.marginTop = 0;
    h1.innerHTML = '<b>'+status+'</b>';
    h4.innerHTML = '<b>'+statusText+'</b>.';

    div.appendChild(h1);
    div.appendChild(h4);

    rootDiv.appendChild(div);

    return rootDiv.innerHTML;
}

function route(url, template) {
    const route = {
        url: url,
        params: {},
        location: './views/' + template + '.html'
    };
    ROUTES.push(route);
}

function checkURL(path) {
    if (ROUTES && ROUTES instanceof Array) {
        const route = ROUTES.find((elt) => {
            if (elt.url == path) {
                return true;
            }
        });
        if (route) {
            return route;
        }
        throw new Error('This Route Is Not Defined In const Routes.');
    }
    throw new Error('Const Routes Not Defined Or Invalid Declaration.');
}

function setRootPage() {
    var url = window.location.hash.slice(1) || "/";
    const tabItems = root.querySelectorAll('.tab-item');
    tabItems.forEach(elt => {
        const tab = elt.getAttribute(dTabRouting).trim();
        if (url == tab) {
            const elementActive = elt.parentElement.querySelector('.tab-item.active');
            elementActive.classList.remove('active');
            elt.classList.add('active');
        }
    });
    navigate(url, root);
}

function navigate(url) {
    const route = checkURL(url);
    history.pushState({}, 'newUrl', '#' + url);

    const http = new XMLHttpRequest();
    http.onreadystatechange = (function() {
        if (this.readyState == 4) {
            if (this.status == 200) {
                const responseDocument = document.createElement('div');
                responseDocument.innerHTML = this.responseText;
                const outlets = root.querySelectorAll('*['+outletName+']');
                for (let i = 0; i < outlets.length; i++) {
                    const elt = outlets.item(i);
                    const name = elt.getAttribute(outletName).trim();
                    const newDocumentElement = responseDocument.querySelector('outlet[name="'+ name +'"]');
                    // nodes.fill(null);
                    if(newDocumentElement) {
                        elt.innerHTML = newDocumentElement.innerHTML;
                        setCache(elt.innerHTML, name);
                        superLoader(elt);
                    } else {
                        setCache(null, name);
                        elt.innerHTML = null;
                    }
                }
            } else {
                root.querySelector('.body').innerHTML = createErrorPage(this.status, this.statusText);
            }
            removePush();
        }
    });
    http.open("GET", route.location);
    http.send();

    return true;
}

function triggerEvent(event, attribute) {
    event.preventDefault();
    eval(attribute);
    const newBody = getCache();
    root.innerHTML = newBody.innerHTML;
    superLoader();
}



window.onload = () => {
    splashScreen();
    setRootPage();
    startApp();
    overlayEffect();
    console.log(nodes);
};

function addPush() {
    // root.classList.add('push');
    // root.classList.remove('pop');
}
function removePush() {
    // setTimeout(() => {
    //     root.classList.remove('push');
    //     root.classList.add('pop');
    // }, 1000);
}
function splashScreen() {
    const splash = document.getElementById('preloader-active');
    if (splash) {   
        setTimeout(()=> {
            splash.classList.add('remove');
            splash.remove();
            // root.style.overflow = 'visible';
            root.classList.add('view');
        }, 500);
    }
}

function overlayEffect() {
    var overlay = document.createElement('div');
    overlay.classList.add('app-overlay');
    overlay.addEventListener('click', (e) => {
        e.preventDefault();
        closeDrawer();
        closeModal();
    });
    root.prepend(overlay);
}

function openDrawer(drawer) {
    let appDrawer;
    let appOverlay = document.querySelector('.app-overlay');
    appOverlay.classList.add('visible');
    if (drawer) {
        appDrawer = document.querySelector('.app-drawer[_drawer="' + drawer + '"]');
    } else {
        appDrawer = document.querySelector('.app-drawer');
    }
    if (appDrawer) {
        appDrawer.classList.add('open');
    }
}
function closeDrawer(drawer) {
    let appDrawer;
    let appOverlay = document.querySelector('.app-overlay');
    appOverlay.classList.remove('visible');
    if (drawer) {
        appDrawer = document.querySelectorAll('.app-drawer[_drawer="' + drawer + '"]');
    } else {
        appDrawer = document.querySelectorAll('.app-drawer');
    }
    appDrawer.forEach(elt => {
        elt.classList.remove('open');
    });
}

function openModal(modal) {
    let appModal;
    let appOverlay = document.querySelector('.app-overlay');
    appOverlay.classList.add('visible');
    if (modal) {
        appModal = document.querySelector('.app-modal[_modal="' + modal + '"]');
    } else {
        appModal = document.querySelector('.app-modal');
    }
    if (appModal) {
        appModal.classList.add('open');
    }
}
function closeModal(modal) {
    let appModal;
    let appOverlay = document.querySelector('.app-overlay');
    appOverlay.classList.remove('visible');
    if (modal) {
        appModal = document.querySelectorAll('.app-modal[_modal="' + modal + '"]');
    } else {
        appModal = document.querySelectorAll('.app-modal');
    }
    appModal.forEach(elt => {
        elt.classList.remove('open');
    });
}

function startApp() {
    try {
        superLoader();
    } catch (error) {
        var errorOutput = error.stack.replace(/[\w]+:\/\/[\w$\.'":\/?#%&~!@^-_+*<>`]+/mg, function (match) {
            return '<a href="'+match+'">'+match+'</a>';
        });
        errorOutput = errorOutput.replace(/( at )([\w]*)/mg, function (match, $1, $2) {
            return '<br>'+ $1 + '<b>'+$2+'</b>';
        });
        const rootDiv = document.createElement('div');
        const doc = document.createElement('div');
        doc.style.position = "fixed";
        doc.style.left = 0;
        doc.style.right = 0;
        doc.style.top = 0;
        doc.style.padding = '10px';
        doc.innerHTML = '<h2>'+error.name+'</h2><h4>'+error.message+'</h4><hr><p>'+errorOutput+'</p>';
    
        rootDiv.appendChild(doc);
        root.innerHTML = rootDiv.innerHTML;
        console.error(error.stack);
    }
}

function setState() {
    const elements = document.querySelectorAll('*[_state]');
    elements.forEach(element => {
        var varName = element.getAttribute('_state');
        const node = nodes.find(find => {
            if (find.varName == varName) {
                return true;
            }
        });
        const div = document.createElement('div');
        div.innerHTML = node.node;
        const output = superLoader(div);
        element.innerHTML = output.innerHTML;
    });
}

// var object = {
//     nom: 'Idriss CHIFO',
//     sexe: 'Masculin',
//     age: 24
// };
// var example = 'object.nom';
// var outputWindowVar = '';
// var result = example.replaceAll(/([a-zA-Z]+)/mg, function (match) {
//     console.log(match);
//     outputWindowVar += window[match];
//     return outputWindowVar;
// });
// console.log(object);
// console.log(example);
// console.log(result);
