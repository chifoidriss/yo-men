// document.onload = function () {
// }


window.onscroll = function() {
    scroll()
}
// document.body.onload = () => {
//     scroll()
// }

function scroll() {
    const header = document.getElementById("header")
    const content = document.getElementById("content")
    
    if (header && content) {
        const navbar = content.querySelector('.navbar');
        if (document.body.scrollTop > 10 || document.documentElement.scrollTop > 10) {
            header.style.height = "0";
            content.style.marginTop = "0";
            navbar.style.position = "fixed";
            navbar.style.background = "#1abc9c";
            navbar.style.color = "#FFF";
        } else {
            header.style.height = "30vh";
            content.style.marginTop = "30vh";
            navbar.style.position = "absolute";
            navbar.style.background = "#DDD";
            navbar.style.color = "#000";
        }
    }
}