/*jshint esversion: 6 */

var title = 'Bamendjo';
var currentDate = new Date();
var viewMonth = [];

const routes = [
    {
        url: '/',
        location: './views/home.html'
    },
    {
        url: '/compte',
        location: './views/compte.html'
    },
    {
        url: '/aide',
        location: './views/aide.html'
    },
    {
        url: '/connexion',
        location: './views/login.html'
    }
];


/*
|    Class 
*/

class Goba {
    static getDay(date) {
        const REF_DATE = new Date('1970-01-07');
        var nbJours = date.getTime() - REF_DATE.getTime();
        return Math.ceil(nbJours/(1000*60*60*24)) % 8;
    }
    
    static jour(index) {
        const GOBA_JOURS = [
            'Katꭏꭏ',
            'KapϽt',
            'Mɛtàgŋouɛ',
            'Tsuír',
            'PϽ`buoh',
            'MϽ`tà',
            'Chûgŋouɛh',
            'Djɛula`a'
        ];

        return GOBA_JOURS[index];
    }
    
    static semaine(index) {
        const _JOURS = [
            'Dimanche',
            'Lundi',
            'Mardi',
            'Mercredi',
            'Jeudi',
            'Vendredi',
            'Samedi'
        ];

        return _JOURS[index];
    }
    
    static mois(index) {
        const _MOIS = [
            'Janvier',
            'Février',
            'Mars',
            'Avril',
            'Mai',
            'Juin',
            'Juillet',
            'Août',
            'Septembre',
            'Octobre',
            'Novembre',
            'Décembre',
        ];

        return _MOIS[index];
    }
    
    static nbJourMois(month, year) {
        return new Date(year, month+1, 0).getDate();
    }
}



function getTodayDay(){
    var date = new Date();
    var tmp = new Date(date.getFullYear(),date.getMonth(),date.getDate());
    const element = {
        id: date.getDate(),
        date: Goba.getDay(tmp),
        jour: Goba.jour(Goba.getDay(tmp)),
        semaine: Goba.semaine(tmp.getDay()),
        mois: Goba.mois(tmp.getMonth()),
        year: tmp.getFullYear()
    };
    return element;
}

function onChangeMonth(val) {
    var currentMonth = currentDate.getMonth();
    currentDate.setMonth(currentMonth+val);
    setViewMonth(currentDate);
}

function onChangeYear(val) {
    var currentYear = currentDate.getFullYear();
    currentDate.setFullYear(currentYear+val);
    setViewMonth(currentDate);
}

function setViewMonth(date) {
    viewMonth = [];
    title = Goba.mois(date.getMonth()) +' '+ date.getFullYear();
    const nb = Goba.nbJourMois(date.getMonth(), date.getFullYear());
    for (var i = 1; i <= nb; i++) {
        var tmp = new Date(date.getFullYear(),date.getMonth(),i);
        const element = {
            id: i,
            date: Goba.getDay(tmp),
            jour: Goba.jour(Goba.getDay(tmp)),
            semaineNum: tmp.getDay(),
            semaine: Goba.semaine(tmp.getDay()),
        };
        viewMonth.push(element);
    }
}

setViewMonth(currentDate);
